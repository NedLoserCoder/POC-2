// Array de objetos
const registro = [
    { nome: "Joao", idade: 17, mensalidade: 2000, curso: "Programação", qtdSemestres: 4, bolsa: false },
    { nome: "Julia", idade: 22, mensalidade: 1800, curso: "Ciências Sociais", qtdSemestres: 2, bolsa: true },
    { nome: "Paulo", idade: 19, mensalidade: 3500, curso: "Engenharia", qtdSemestres: 1, bolsa: true },
    { nome: "Laura", idade: 25, mensalidade: 1500, curso: "Moda", qtdSemestres: 5, bolsa: false },
    { nome: "Samuel", idade: 29, mensalidade: 3000, curso: "Veterinária", qtdSemestres: 7, bolsa: false }
];

// Colocamos esse registro para aparecer na tela apenas como parâmetro para os métodos array
console.log(registro);

// Spread (...) - Copiar, combinar ou adicionar elementos no array

// Copiar - Cria uma cópia do array original
const copia = [...registro];

console.log(copia);

// Combinar - Junta dois arrays em um só
const registro2 = [
    { nome: "Caio", idade:18, mensalidade: 2000, curso: "Programação", qtdSemestres: 2, bolsa: false },
    { nome: "Andreas",  idade:19, mensalidade: 2000, curso: "Programação", qtdSemestres: 2, bolsa: false }
];
const combinado = [...registro, ...registro2];

console.log(combinado);

//adicionar - Adiciona elementos ao array
const adicionado = ["ALUNOS DO MACKENZIE", ...registro]

console.log(adicionado);

// Map - Cria um novo array com base nos interesses do programador
const alunosmap = registro.map((aluno) => {
    if (aluno.bolsa === true) {
        return "O aluno/a " + aluno.nome + ", é bolsista";
    } else if (aluno.bolsa === false) {
        return "O aluno/a " + aluno.nome + ", não é bolsista";
    } else {
        return "informação inválida";
    }
});
console.log(alunosmap);

// Reduce - Soma todas as mensalidades
const alunosred = registro.reduce((total, aluno) => total + aluno.mensalidade, 0);
console.log(alunosred);

// Filter - Filtra os objetos com base em algum critério
const alunosfilt = registro.filter((aluno) => aluno.idade >= 20);
console.log(alunosfilt);

// Sort - Ordena os objetos por qtdSemestres e depois por curso

// Ordenar por qtdSemestres
const alunossort = [...registro].sort((a, b) => {
    if (a.qtdSemestres < b.qtdSemestres) return -1;
    if (a.qtdSemestres > b.qtdSemestres) return 1;
    return 0;
});
console.log(alunossort);

// Ordenar por curso
const alunosalfa = [...registro].sort((a, b) => {
    if (a.curso < b.curso) return -1;
    if (a.curso > b.curso) return 1;
    return 0;
});
console.log(alunosalfa);
